package com.example.seg2105_f19_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SingleService extends AppCompatActivity {

    String name;
    String role;

    private final FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference ref = database.getReference("services");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_service);
        Intent intent = getIntent();
        name = (String)intent.getSerializableExtra("name");
        role = (String)intent.getSerializableExtra("role");
        ((TextView)findViewById(R.id.infoText)).setText("Name: " + name + "\n" + "Perfomed by: " + role);
    }

    public void onEdit (View view) {
        Intent intent = new Intent(getApplicationContext(), AddService.class);
        intent.putExtra("name", name);
        intent.putExtra("role", role);
        startActivityForResult(intent, 0);
    }

    public void onDelete (View view) {
        ref.child(name).removeValue();
        onBack(view);
    }

    public void onBack (View view) {
        Intent intent = new Intent(getApplicationContext(), ViewServices.class);
        startActivityForResult(intent, 0);
    }

}
