package com.example.seg2105_f19_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class WelcomeScreen extends AppCompatActivity {

    private String firstName;
    private String role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);
        Intent intent = getIntent();
        firstName = (String)intent.getSerializableExtra("firstName");
        role = (String)intent.getSerializableExtra("role");
        ((TextView)findViewById(R.id.welcome)).setText("Welcome, " + firstName + "! You are logged in as a " + role +".");
    }

}
