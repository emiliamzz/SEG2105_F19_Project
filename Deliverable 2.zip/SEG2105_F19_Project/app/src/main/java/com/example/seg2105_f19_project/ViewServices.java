package com.example.seg2105_f19_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewServices extends AppCompatActivity {

    private final FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference ref = database.getReference("services");
    private List<Service> services = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_services);
        readServices();
    }

    private void readServices () {
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                services.clear();
                for (DataSnapshot key : dataSnapshot.getChildren()) {
                    String name = key.child("name").getValue().toString();
                    String role = key.child("role").getValue().toString();
                    Service service = new Service(name, role);
                    services.add(service);
                    makeButton(service);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }
        });
    }

    private void makeButton(final Service service) {
        LinearLayout linearLayout = (LinearLayout)findViewById(R.id.listOfServices);
        Button button = new Button(this);
        button.setText(service.getName());
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SingleService.class);
                intent.putExtra("name", service.getName());
                intent.putExtra("role", service.getRole());
                startActivityForResult(intent, 0);
            }
        });
        linearLayout.addView(button);
    }

    public void onAddService (View view) {
        Intent intent = new Intent(getApplicationContext(), AddService.class);
        startActivityForResult(intent, 0);
    }

    public void onBack (View view) {
        Intent intent = new Intent(getApplicationContext(), WelcomeAdmin.class);
        startActivityForResult(intent, 0);
    }
}
