package com.example.seg2105_f19_project;

public class Service {

    String name;
    String role;

    public Service(String name, String role) {
        this.name = name;
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }

}
