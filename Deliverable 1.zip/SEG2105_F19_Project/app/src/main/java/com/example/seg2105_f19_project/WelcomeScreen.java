package com.example.seg2105_f19_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class WelcomeScreen extends AppCompatActivity {

    private String username;
    private String name;
    private String role;

    private final FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference ref = database.getReference("users");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);
        Intent intent = getIntent();
        username = (String)intent.getSerializableExtra("user");
        readUsers();
    }

    private void readUsers () {
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot key : dataSnapshot.getChildren()) {
                    if (key.getKey().equals(username)) {
                        System.out.println("hello");
                        for (DataSnapshot thing : key.getChildren()) {
                            if (thing.getKey().equals("firstName")) {
                                name = thing.getValue().toString();
                            } else if (thing.getKey().equals("role")) {
                                role = thing.getValue().toString();
                            }
                        }
                        break;
                    }
                    TextView editText = (TextView)findViewById(R.id.welcome);
                    editText.setText("Welcome " + name + "! You are logged in as a " + role);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }
        });
    }

}
