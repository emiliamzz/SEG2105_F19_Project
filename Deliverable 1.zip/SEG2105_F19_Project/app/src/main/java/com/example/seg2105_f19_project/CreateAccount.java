package com.example.seg2105_f19_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

public class CreateAccount extends AppCompatActivity {

    private final FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference ref = database.getReference("users");
    private List<User> users = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        readUsers();
    }

    private void readUsers () {
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                users.clear();
                for (DataSnapshot key : dataSnapshot.getChildren()) {
                    String firstName = "";
                    String lastName = "";
                    String username = "";
                    String passHash = "";
                    String role = "";
                    for (DataSnapshot thing : key.getChildren()) {
                        if (thing.getKey().equals("firstName")) {
                            firstName = thing.getValue().toString();
                        } else if (thing.getKey().equals("lastName")) {
                            lastName = thing.getValue().toString();
                        } else if (thing.getKey().equals("username")) {
                            username = thing.getValue().toString();
                        } else if (thing.getKey().equals("passHash")) {
                            passHash = thing.getValue().toString();
                        } else {
                            role = thing.getValue().toString();
                        }
                    }
                    User user = new User(firstName, lastName, username, passHash, role);
                    users.add(user);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }
        });
    }

    public void onCreateAccount (View view) {
        String password = ((EditText)findViewById(R.id.password)).getText().toString();
        String confirmPassword = ((EditText)findViewById(R.id.confirmPassword)).getText().toString();
        if (!password.equals(confirmPassword)) {
            return;
        }
        String username = ((EditText)findViewById(R.id.username)).getText().toString();
        for (User user : users) {
            if (username.equals(user.getUsername())) {
                return;
            }
        }
        String passwordHash = null;
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] hash = messageDigest.digest(password.getBytes("UTF-8"));
            StringBuffer hexString = new StringBuffer();
            for (int i=0; i<hash.length; i++) {
                String hex = Integer.toHexString(0xff & hash[i]);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            passwordHash = hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.out.println("Something went wrong: " + e);
            return;
        } catch (UnsupportedEncodingException e) {
            System.out.println("Something went wrong: " + e);
            return;
        }
        String firstName = ((EditText)findViewById(R.id.firstName)).getText().toString();
        String lastName = ((EditText)findViewById(R.id.lastName)).getText().toString();
        String role = "patient";
        if (((RadioGroup)findViewById(R.id.role)).getCheckedRadioButtonId() == R.id.employee) {
            role = "employee";
        }
        User user = new User(firstName, lastName, username, passwordHash, role);
        ref.child(username).setValue(user);
        goToLogin(view);
    }

    public void goToLogin (View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivityForResult(intent, 0);
    }

}
